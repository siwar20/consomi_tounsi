package tn.esprit.spring.pdf;

public interface PdfService {
    String toPDF(int idReclamation);
}


