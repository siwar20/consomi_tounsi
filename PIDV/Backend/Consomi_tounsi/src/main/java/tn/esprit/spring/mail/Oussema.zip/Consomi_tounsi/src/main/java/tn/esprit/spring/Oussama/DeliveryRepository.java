package tn.esprit.spring.Oussama;

import org.springframework.data.repository.CrudRepository;

public interface DeliveryRepository extends CrudRepository<Delivery,Integer> {
}
