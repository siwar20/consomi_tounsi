package tn.esprit.spring.entity;

public enum Type {
	Réfrigérateur, normal
	
	
}
